import { Component, Input } from '@angular/core'

import { Display } from '../display/display'

@Component({
	moduleId: module.id,
	selector:'display-details',
	templateUrl:'./display-details.component.html',
	styleUrls:['./display-details.component.ts']
})

export class DisplayDetailsComponent{

@Input()
data: Display;


}