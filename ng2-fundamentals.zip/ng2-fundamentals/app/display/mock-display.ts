import { Display } from './display'

export const MockData:Display[] = [
		{id:11, name:"abc"},
		{id:12, name:"def"},
		{id:13, name:"ghi"}
	];
