"use strict";
exports.MockData = [
    { id: 11, name: "abc" },
    { id: 12, name: "def" },
    { id: 13, name: "ghi" }
];
//# sourceMappingURL=mock-display.js.map