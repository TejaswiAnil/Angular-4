export class Display{
 id: number;
 name: string;
}
