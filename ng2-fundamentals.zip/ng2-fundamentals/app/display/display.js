"use strict";
var Display = (function () {
    function Display() {
    }
    return Display;
}());
exports.Display = Display;
//# sourceMappingURL=display.js.map