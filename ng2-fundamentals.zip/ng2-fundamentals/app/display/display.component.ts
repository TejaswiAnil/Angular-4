import { Component, OnInit } from '@angular/core'

import { Display } from './display'
import { MockData } from './mock-display'

@Component({
	moduleId: module.id,
	selector:'app-display',
	templateUrl:'./display.component.html',
	styleUrls:['./display.component.css']
})

export class DisplayComponent implements OnInit{
	
	selectedVal: Display;
	dataList: Display[];
	displayStr:string;

	ngOnInit() {
	 this.displayStr="Display Component";
	 this.dataList=MockData;
	}
	
	constructor(){

	}

	selectedItem(list: Display) {
		this.selectedVal = list;
	}


}		