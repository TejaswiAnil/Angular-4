import { NgModule } from '@angular/core'
import { BrowserModule } from '@angular/platform-browser'
import { FormsModule } from '@angular/forms'

import { AppComponent } from './app.component'
import { DisplayComponent } from './display/display.component'
import { DisplayDetailsComponent } from './display-details/display-details.component'


@NgModule({
	imports:[
			BrowserModule,
			FormsModule
			],
  	declarations: [
  			AppComponent,
  			DisplayComponent,
  			DisplayDetailsComponent
  			],
  	bootstrap: [AppComponent]
})

export class AppModule{}